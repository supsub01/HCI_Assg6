/**
 * Class to define HighScore Display Activity
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame.highscores;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.content.Intent;

import com.example.reactiontimegame.MainActivity;
import com.example.reactiontimegame.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    private static final int RC_ADD_SCORE =1 ;
    ListView listView; //ListView component that displays the high scores.
    List<HighScoreData> arrayList; //arrayList data structure that holds the high scores.

    //Called every time the app starts
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        FileIO fio = new FileIO(this);
        listView=(ListView) findViewById(R.id.listview);
        arrayList = fio.read_file();

        Intent data= getIntent();
        String newName = data.getStringExtra("newName");
        String newScore = data.getStringExtra("newScore");
        String newDate = data.getStringExtra("newDate");

        //Remove largest score if>20 scores
        if(arrayList.size()>=20) arrayList.remove(Collections.max(arrayList));
        arrayList.add(new HighScoreData(newName,newScore,newDate));

        fio.write_to_file(arrayList);
        get_scores();
    }

    //Function to get scores from file
    private void get_scores(){
        FileIO fileIO = new FileIO(this);
        arrayList = fileIO.read_file();
        Collections.sort(arrayList);
        StableArrayAdapter scoreAdapter = new StableArrayAdapter(this,R.layout.score_view,arrayList);
        listView.setAdapter(scoreAdapter);
    }

    //Hook called whenever an item in options menu is selected
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.add){
            Intent start_new_game = new Intent(this, MainActivity.class);
            startActivity(start_new_game);
            finish();
            return true;
        }

        return false;
    }

//    //Function to start addScoreActivity
//    private void openAddScoreActivity() {
//        Intent addScoreIntent = new Intent(this,addScoreActivity.class);
//        startActivityForResult(addScoreIntent, RC_ADD_SCORE);
//    }

    //Function to create the options menu when user opens the menu for the first time
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==RC_ADD_SCORE){
            //Update listview with new highscore if exists
            if(resultCode==RESULT_OK){
                String newName = data.getStringExtra("newName");
                String newScore = data.getStringExtra("newScore");
                String newDate = data.getStringExtra("newDate");

                arrayList.add(new HighScoreData(newName,newScore,newDate));

                FileIO fio = new FileIO(this);
                fio.write_to_file(arrayList);
                get_scores();
            }
        }
    }
}