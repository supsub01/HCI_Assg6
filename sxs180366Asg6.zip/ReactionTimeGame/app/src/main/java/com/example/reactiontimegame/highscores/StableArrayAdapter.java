/******************************************************************************
 * Class that is used to display high score lists.  This is the adapter, or
 * model, that contains the strings.  The scores list is tab-separated values
 * with the score, name, and date, in that order.
 *
 * Written by John Cole.
 ******************************************************************************/
package com.example.reactiontimegame.highscores;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.util.TypedValue;
import android.view.LayoutInflater;
import java.util.List;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.reactiontimegame.R;


public class StableArrayAdapter extends ArrayAdapter<HighScoreData> {
    List<HighScoreData> values;

    public StableArrayAdapter(Context context, int textViewResourceId, List<HighScoreData> objects)
    {
        super(context, textViewResourceId, objects);
        values = objects;
    }

    /****************************************************************************
     * This overridden function is called for each line in the list.  Split the
     * data string on tabs and put each component into the TextView in the View
     * we return, which is then displayed.
     *
     * Since it does not seem possible to assign each of the components of the
     * ListView line a percentage of the screen width, that is done in the code
     * below.  These look reasonably good on both my Asus tablet and my Galaxy
     * S5 phone.
     * @param position
     * @param cvtView
     * @param parent
     * @return
     ****************************************************************************/
    @Override
    public View getView(int position, View cvtView, ViewGroup parent)
    {
        int width = parent.getWidth();
        Context cx = this.getContext();
        LayoutInflater inflater = (LayoutInflater) cx.getSystemService(cx.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.score_view, parent, false);

        HighScoreData str = values.get(position);
        String name=str.name();
        String score=str.score();
        String date=str.date();

        AssetManager assetManager = cx.getAssets();

        TextView tvName = (TextView) rowView.findViewById(R.id.sl_name);
        tvName.setWidth((int) (width * .40));
        tvName.setText(name);
        tvName.setTextColor(Color.BLACK);
        tvName.setTextSize(TypedValue.COMPLEX_UNIT_SP,18);


        TextView tvScore = (TextView) rowView.findViewById(R.id.sl_score);
        tvScore.setWidth((int) (width * .30));
        tvScore.setText(score);
        tvScore.setTextColor(Color.BLACK);
        tvScore.setTextSize(TypedValue.COMPLEX_UNIT_SP,25);

        TextView tvDate = (TextView) rowView.findViewById(R.id.sl_date);
        tvDate.setWidth((int) (width * .5));
        tvDate.setText(date);
        tvDate.setTextColor(Color.GRAY);
        tvDate.setTextSize(TypedValue.COMPLEX_UNIT_SP,17);

        return rowView;
    }

}
