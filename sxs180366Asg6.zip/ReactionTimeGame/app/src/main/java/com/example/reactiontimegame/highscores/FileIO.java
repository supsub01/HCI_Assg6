/**
 * Class to define File Input Output handling
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame.highscores;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.List;

public class FileIO {
    Context context;
    private static final String high_scores_file="high_scores.txt";

    //Constructor
    public FileIO(Context context) {
        this.context = context;
    }

    //Method to read file containing high scores
    public ArrayList<HighScoreData> read_file() {

        ArrayList<HighScoreData> scores_data_list=new ArrayList<>();
        String file_path = context.getFilesDir()+"/"+high_scores_file;
        final File file = new File(file_path);

        try {
            if (file.exists()) {
                FileInputStream ip = new FileInputStream(file);
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(ip));

                //Read each line of file into a HighScoreData structure and add to scores_data_list
                String line;
                while ((line=bufferedReader.readLine()) != null) {
                    String[] score_data = line.split("\t");
                    HighScoreData score = new HighScoreData(score_data[0],score_data[1],score_data[2]);
                    scores_data_list.add(score);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scores_data_list;

    }

    //Fucntion to write Highscore list contents to file
    public boolean write_to_file(List<HighScoreData> scores_data_list){
        String path = context.getFilesDir()+"/"+high_scores_file;
        File file = new File(path);

        //Create file (if not exist) and write each line to file.
        if(!file.exists()){
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            FileWriter fw = new FileWriter(file);
            for(HighScoreData score: scores_data_list){
                String line=score.name()+"\t"+score.score()+"\t"+score.date();
                fw.append(line+"\n");
            }
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }
}
