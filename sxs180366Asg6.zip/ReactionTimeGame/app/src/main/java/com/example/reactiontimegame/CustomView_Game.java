/**
 * Class to define Game View
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.os.CountDownTimer;
import android.os.Debug;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.os.Handler;


import androidx.annotation.Nullable;

import com.example.reactiontimegame.highscores.HighScoreData;
import com.example.reactiontimegame.highscores.MainActivity2;
import com.example.reactiontimegame.highscores.FileIO;


import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.LogRecord;

import static android.graphics.RectF.intersects;

public class CustomView_Game extends View {

    String[] allColors = new String[]{"Red", "Orange", "Yellow", "White", "Green", "Blue", "Purple"};

    int frameRate=1000;
    int NUM_SHAPES;
    long startTime=System.currentTimeMillis();

    //Variables that maintain current game state
    List<Shape> CurrentShapes; //list of active balloons
    int correct_shape,correct_color;
    boolean init=true; //flag true if start of game
    int correctTouchedCount;
    int missedShapesCount=0;
    long penalty=0;

    //Variables that hold screen elements
    TextView correctTouchedCountText, timerText, gameDescText, correctTouchedCountText_label;
    Button viewScoresButton;

    //Utility Elements
    Handler h;

    public CustomView_Game(Context context) {
        super(context);
        CurrentShapes = new LinkedList<Shape>();
    }

    public CustomView_Game(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        CurrentShapes = new LinkedList<Shape>();
    }


    //Function to setup current game
    public void setCurrentGame(int shape, int color, TextView correctTouchedCountText_label,
                               TextView correctTouchedCount_text, TextView timer, TextView gameDesc,
                               Button viewScores) {

        this.correct_shape = shape;
        this.correct_color = color;

        correctTouchedCountText = correctTouchedCount_text;
        timerText = timer;
        gameDescText=gameDesc;
        if(shape==0) gameDesc.setText(allColors[color]+" Squares");
        else gameDesc.setText(allColors[color]+" Circles");
        this.viewScoresButton = viewScores;
        this.correctTouchedCountText_label=correctTouchedCountText_label;
    }

    //Function to terminate game
    public void end_game() {
        CurrentShapes.clear();

        //Check if it a highscore
        FileIO fileIO = new FileIO(getContext());
        ArrayList<HighScoreData> scores_data_list=fileIO.read_file();
        int score= Integer.valueOf((String) timerText.getText());
        if(scores_data_list.size()<20 || score<Integer.valueOf(Collections.max(scores_data_list).score())){
            viewScoresButton.setVisibility(VISIBLE);
        }else{
            viewScoresButton.setVisibility(VISIBLE);
        }

        gameDescText.setText("GAME OVER!");
        correctTouchedCountText.setText(String.valueOf(missedShapesCount));
        correctTouchedCountText_label.setText(("Missed Shapes:"));

    }

    //Function called when touch event occurs
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (init == true || event.getAction() != MotionEvent.ACTION_DOWN) return false;

        Shape touchedBalloon = null;
        //Check if a balloon is touched and add it to the list
        for (Shape shp : CurrentShapes) {
            if (shp.x < event.getX() && event.getX() < shp.x + shp.size && shp.y > event.getY() && event.getY() > shp.y - shp.size) {
                touchedBalloon = shp;
                break;
            }
        }

        // Update correctTouchedCount and remove touched shape
        if (touchedBalloon != null) {
            if (touchedBalloon.color == correct_color && touchedBalloon.shape == correct_shape) {

                correctTouchedCount++;
            }
            correctTouchedCountText.setText(String.valueOf(correctTouchedCount));
            CurrentShapes.remove(touchedBalloon);
        }

        return super.onTouchEvent(event);
    }

    //Function to return if a shape overlaps with any other current shapes
    boolean checkOverlap(Shape new_shape){
        for(Shape shp:CurrentShapes){
            if(shp!=new_shape && intersects(new_shape.rectF,shp.rectF)) return true;
        }
        return false;
    }

    void shift_shapes(){
        for(Shape shp: CurrentShapes){
            if(shp.shift()){
                if(checkOverlap(shp)) {
                    shp.unshift();
                }
                else System.out.println("Shifted!");
            }
        }
    }

    //Called everytime Game View is redrawn
    @Override
    protected void onDraw(Canvas canvas){
        super.onDraw(canvas);

        //Number of shapes (6-12) on screen
        Random rand = new Random();
        NUM_SHAPES = rand.nextInt((12 - 6) + 1) + 6;

        int canvasHeight = getHeight();
        int canvasWidth = getWidth();

        //Initialise Shapes on start of game
        //if it is the start if game then initialize the balloons
        if(init){

            //generate random shapes
            for(int i=0 ; i< NUM_SHAPES ; i++){
                if(rand.nextInt(2) == 1){
                    Shape new_square=new Square(getContext(),canvasHeight,canvasWidth);
                    while(checkOverlap(new_square)){
                        new_square=new Square(getContext(),canvasHeight,canvasWidth);
                    }
                    CurrentShapes.add(new_square);
                }else{
                    Shape new_circle=new Circle(getContext(),canvasHeight, canvasWidth);
                    while(checkOverlap(new_circle)){
                        new_circle=new Circle(getContext(),canvasHeight,canvasWidth);
                    }
                    CurrentShapes.add(new_circle);
                }

            }
            init=!init;
        }

        //Remove expired shapes
        List<Shape> toRemove = new ArrayList();
        for(int i=0;i<CurrentShapes.size();i++){
            int age=(int) (System.currentTimeMillis()- CurrentShapes.get(i).birthtime)/1000;

            if(CurrentShapes.get(i).lifetime<=age) {
                toRemove.add(CurrentShapes.get(i));
                //Add lifetime of expired correct shape-color to time
                if(CurrentShapes.get(i).color==correct_color && CurrentShapes.get(i).shape==correct_shape) {
                    penalty += CurrentShapes.get(i).lifetime;
                    missedShapesCount++;
                }
            }
        }
        CurrentShapes.removeAll(toRemove);

        //Shift all the existing shapes by 20 pixels in any direction
        shift_shapes();

        //Create diff number of random replacement shapes
        int diff = NUM_SHAPES - CurrentShapes.size();

        //create new random shapes when they are popped or disappear
        for(int i=0; i < diff ; i++){
            Random r = new Random();
            if(r.nextInt(2) == 1){
                Shape new_square=new Square(getContext(),canvasHeight,canvasWidth);
                while(checkOverlap(new_square)){
                    new_square=new Square(getContext(),canvasHeight,canvasWidth);
                }
                CurrentShapes.add(new_square);
            }else{
                Shape new_circle=new Circle(getContext(),canvasHeight, canvasWidth);
                while(checkOverlap(new_circle)){
                    new_circle=new Circle(getContext(),canvasHeight,canvasWidth);
                }
                CurrentShapes.add(new_circle);
            }
        }

        //Draw all shapes
        for(Shape shp : CurrentShapes){
            shp.drawShape(canvas);
        }

        //The following block of code draws the timerText
        h = new Handler();
        Runnable r = new Runnable() {

            @Override
            public void run() {
                invalidate();
                long millis = System.currentTimeMillis() - startTime +(penalty*1000);
                timerText.setText(String.valueOf(millis / 1000));
            }
        };
        if(correctTouchedCount<3) {
            h.postDelayed(r, frameRate);
        }
        else{
            end_game();
        }
    }


}
