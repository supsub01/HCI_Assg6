/**
 * Class to define Add Score Activity
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame.highscores;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.EditText;
import android.view.MenuItem;

import com.example.reactiontimegame.R;

import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;

//Activity to add a new highscore
public class addScoreActivity  extends AppCompatActivity {

    //User inputs new name, new score and new date
    EditText new_name;
    EditText new_score;
    EditText new_date;


    //User clicks Save menuItem upon filling valid data into all fields
    MenuItem save;

    //flag to check data validity
    boolean valid_flag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_score);

        setTitle("Add a new Highscore!");

        //Get user entered values
        new_name = findViewById(R.id.new_name);
        new_score = findViewById(R.id.new_score);

        //Get score from previous game
        Intent intent = getIntent();
        new_score.setText(intent.getStringExtra("score"));
        new_score.setEnabled(false);

        new_date = findViewById(R.id.new_date);
        new_date.setText(new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date()));

        //Text change listeners for name, score and date:
        //Upon change of any of the data fields, a validation function is called to ensure no bad data is entered

        new_name.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                validate_dataFields();
            }
        });

        new_score.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                validate_dataFields();
            }
        });

        new_date.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {}

            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                validate_dataFields();
            }
        });


    }

    //Function to check validity of name,score and date fields
    private void validate_dataFields(){

        String newName = new_name.getText().toString();
        String newScore = new_score.getText().toString();
        String newDate = new_date.getText().toString();

        boolean name_flag =  false;
        if(!newName.isEmpty() && newName.length() <=30){
            new_name.setError(null);
            name_flag = true;
        }else{
            new_name.setError("1-30 character length only");
        }

        boolean score_flag = false;
        if(!newScore.isEmpty()){
            try {
                if (Integer.parseInt(newScore) <= 0) {
                    new_score.setError("positive integers only");
                } else {
                    new_score.setError(null);
                    score_flag = true;
                }
            } catch (Exception e){
                new_score.setError("positive integers only");
            }
        }

        boolean date_flag = false;
        if(!newDate.isEmpty()){
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
            dateFormat.setLenient(false);
            Date now = new Date();
            try {
                if(now.compareTo(dateFormat.parse(newDate.trim()))<0){
                    date_flag = false;
                    new_date.setError("No future high scores.");
                }
                else{
                    date_flag = true;
                    new_date.setError(null);
                }
            } catch (ParseException pe) {
                new_date.setError("MM/dd/yyyy HH:mm:ss");
            }
        }

        valid_flag = name_flag && score_flag && date_flag;

        //Menu contents have changed; must be redrawn
        invalidateOptionsMenu();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.add_score, menu);
        save = menu.findItem(R.id.save);
        save.setEnabled(valid_flag);
        return true;
    }

    //Function to enable or disable save option
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        MenuItem item = menu.findItem(R.id.save);

        if (valid_flag) {
            item.setEnabled(true);
        } else {
            item.setEnabled(false);
        }

        return true;
    }

    //Function to handle save menu selection
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.save){

            Intent viewHighScores = new Intent(getApplicationContext(), MainActivity2.class);
            viewHighScores.putExtra("newName", new_name.getText().toString());
            viewHighScores.putExtra("newScore", new_score.getText().toString());
            viewHighScores.putExtra("newDate", new_date.getText().toString());

            finish();
            startActivity(viewHighScores);
            return true;
        }

        return false;
    }

}
