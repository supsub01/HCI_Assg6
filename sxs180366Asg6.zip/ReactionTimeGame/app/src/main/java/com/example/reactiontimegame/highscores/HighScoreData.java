/**
 * Class to define HighScore Structure
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame.highscores;

import java.text.SimpleDateFormat;
import java.util.Date;
//
//Class that stores the HighScore data (i.e name of player, highscore and date of highscore)
public class HighScoreData implements Comparable<HighScoreData> {
    private String name;
    private String score;
    private String date;

    public HighScoreData(String name, String score, String date) {
        this.name = name;
        this.score = score;
        this.date = date;
    }

    //Function to compare score first, then date-time
    @Override
    public int compareTo(HighScoreData o) {

        int x1 = Integer.parseInt(this.score);
        int x2 = Integer.parseInt(o.score);
        if(x1 > x2){
            return 1;
        }
        else if(x1 == x2) {

            try {
                Date d1 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(this.date);
                Date d2 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").parse(o.date);

                return d2.compareTo(d1);
            } catch (Exception e) {
            e.printStackTrace();
            }
        }
        return -1;
    }

    //Functions to return the name, score and date variables of the class (cannot be accessed otherwise since they are private variables)
    public String date() {
        return date;
    }

    public String name() {
        return name;
    }

    public String score() {
        return score;
    }
}
