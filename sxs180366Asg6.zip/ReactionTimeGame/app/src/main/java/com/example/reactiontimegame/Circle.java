/**
 * Class to define Circle Shape (Shape subclass)
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

public class Circle extends Shape{

    //Array of color values
    int[] allColors = new int[]{Color.RED,Color.rgb(255, 165, 0), Color.YELLOW,Color.WHITE, Color.GREEN,Color.BLUE,Color.rgb(128,0,128)};

    public Circle(Context context, int screenHeight, int screenWidth) {
        super(context, screenHeight, screenWidth);
    }

    //Function to draw circle
    void drawShape(Canvas canvas){
        shape=1;
        rectF = new RectF(x ,y-size ,x+size,y);
        Paint paint = new Paint();
        paint.setColor(allColors[color]);
        canvas.drawCircle(x + size /2,y - size/2,size / 2, paint);
    }
}
