/**
 * Class to define Shape
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.Random;

import static android.graphics.RectF.intersects;

public class Shape {

    //Shape attribute variables
    int size,color,shape, lifetime;
    long birthtime;
    float x , y;
    RectF rectF;

    //Variable used to shift
    int direction; //0=up;1=down;2=left;3=right
    int amount;

    int NUM_COLORS=7;
    int screenHeight,screenWidth;

    public Shape(Context context, int screenHeight, int screenWidth){

        this.screenHeight=screenHeight;
        this.screenWidth=screenWidth;

        Random rand = new Random();
        this.lifetime= 3+rand.nextInt(4);
        this.birthtime=System.currentTimeMillis();
        this.color =  rand.nextInt(NUM_COLORS);
        this.size = (int) ((32+rand.nextInt(64 - 32)) * context.getResources().getDisplayMetrics().density + 0.5f);
        this.y = screenHeight - rand.nextInt(screenHeight - this.size);
        this.x = rand.nextInt(screenWidth - this.size);
        rectF = new RectF(x ,y-size ,x+size,y);
    }

    void drawShape(Canvas canvas){}

    boolean shift(){
        Random rand = new Random();
        direction=rand.nextInt(4);
        amount=20;
        switch(direction) {
            case 0: //Up
                if(this.y-amount>=this.size) this.y-=amount;
                else return false;
                break;
            case 1: //Down
                if(this.y+amount<=screenHeight) this.y+=amount;
                else return false;
                break;
            case 2: //Left
                if(this.x-amount>=0)this.x-=amount;
                else return false;
                break;
            case 3: //Right
                if(this.x+amount+this.size<=screenWidth)this.x+=amount;
                else return false;
                break;
            default:
                // do nothing
        }
        rectF = new RectF(x ,y-size ,x+size,y);
        return true;
    }

    void unshift(){
        switch(direction) {
            case 0:
                this.y+=amount;
                break;
            case 1:
                this.y-=amount;
                break;
            case 2:
                this.x+=amount;
                break;
            case 3:
                this.x-=amount;
                break;
            default:
                // do nothing
        }
        rectF = new RectF(x ,y-size ,x+size,y);
    }

}
