/**
 * Class to define GamePlay Activity
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */

package com.example.reactiontimegame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.reactiontimegame.highscores.addScoreActivity;

//Activity for GamePlay
public class GamePlayActivity extends AppCompatActivity {

    //Variables that hold screen elements
    private ViewGroup mContentView;
    CustomView_Game gameView;
    TextView scoreText,timerText,gameDescText,correctTouchedCountText_label;
    Button viewScoresButton;

    //Variables to hold correct shape and color
    int correct_color, correct_shape;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Update the screen to display gameplay
        setContentView(R.layout.activity_gameplay);

        //Get the Extras of MainActivity
        Intent intent = getIntent();
        correct_shape = intent.getIntExtra("shape",0);
        correct_color= intent.getIntExtra("color",0);

        //Get elements of the screen by id
        mContentView = findViewById(R.id.gameplay);
        gameView = findViewById(R.id.gameArea_view);
        scoreText = findViewById(R.id.scoreText);
        timerText = findViewById(R.id.timeText);
        gameDescText=findViewById(R.id.gameDescText);
        viewScoresButton = findViewById(R.id.highscoreButton);
        correctTouchedCountText_label=findViewById(R.id.textView5);

        //Setup game elements
        gameView.setCurrentGame(correct_shape,correct_color, correctTouchedCountText_label,scoreText, timerText, gameDescText, viewScoresButton);
        //Setting border
        gameView.setBackground(getResources().getDrawable(R.drawable.border));

        //Function called when Start Game Button clicked
        viewScoresButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent to add to highscores
                Intent addToHighscores = new Intent(getApplicationContext(), addScoreActivity.class);
                addToHighscores.putExtra("score",timerText.getText());
                finish();
                startActivity(addToHighscores);
            }
        });
    }

}
