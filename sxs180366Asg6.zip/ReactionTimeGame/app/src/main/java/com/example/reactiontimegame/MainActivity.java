/**
 * Activity to Start Game
 * Written by Supriya Subramanian (sxs180366) for CS6326.001, Assg6
 * */
package com.example.reactiontimegame;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity{

    //Variables that hold screen elements
    Button ok_button;
    TextView game_desc;

    //Variables that maintain current game state
    String color;
    int color_idx;
    int shape;
    int NUM_COLORS=7;

    //Array of color strings
    String[] allColors = new String[]{"Red", "Orange", "Yellow", "White", "Green", "Blue", "Purple"};

    //Function called everytime App starts
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ok_button = findViewById(R.id.ok_button);
        game_desc = findViewById(R.id.game_desc);

        Random rand = new Random();
        shape = rand.nextInt(2); //0=square; 1=circle
        color_idx=rand.nextInt(NUM_COLORS);
        color = allColors[color_idx];

        //Setting game_desc
        if(shape==0){
            game_desc.setText("Touch only the "+ color + " Squares!");

        }else{
            game_desc.setText("Touch only the "+ color + " Circles!");

        }

        //Function called when Start Game Button clicked
        ok_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Intent to start game
                Intent startGame = new Intent(getApplicationContext(),GamePlayActivity.class);
                finish();
                startGame.putExtra("color",color_idx);
                startGame.putExtra("shape",shape);
                startActivity(startGame);

            }
        });

    }
}